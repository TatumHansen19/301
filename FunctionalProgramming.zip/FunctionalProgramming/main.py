import json
import requests
from bs4 import BeautifulSoup

# Initialize an empty dictionary to hold identified elements
identified_elements = {
    "Identifiers": [],
    "TypeNames": [],
    "MethodNames": [],
    "PackageAndImportPaths": [],
    "LiteralValues": [],
    "Operators": []
}

def fetch_java_doc(class_or_interface_name):
    # Adjusted to use a more generic and correct URL forming method
    base_url = "https://docs.oracle.com/javase/8/docs/api/"
    search_url = f"{base_url}{class_or_interface_name.replace('.', '/')}.html"
    return search_url

def fetch_description_from_url(url):
    try:
        response = requests.get(url)
        if response.status_code == 200:
            soup = BeautifulSoup(response.content, 'html.parser')
            description_tag = soup.find('div', class_='description')
            description = description_tag.find('p').text if description_tag else "Description not found."
            return description
        else:
            return "Documentation not available."
    except Exception as e:
        return f"Error fetching documentation: {str(e)}"

def add_with_description(category, node_key, value):
    description = ""
    doc_url = ""
    if node_key == "type":
        description = f"{value} (Data type: Defines the kind of value that a variable can hold or a function can return.)"
    elif node_key == "name":
        if category == "Identifiers":
            description = f"{value} (Identifier: A unique name used to identify a variable, function, or type.)"
        elif category == "MethodNames":
            description = f"{value} (Method Name: The name of a function defined within a class or object.)"
    elif node_key == "path":
        doc_url = fetch_java_doc(value)
        fetched_description = fetch_description_from_url(doc_url)
        description = f"{value} - {fetched_description}"
    elif node_key == "value":
        description = f"{value} (Literal: A raw value directly assigned in the code, such as a number, string, or boolean.)"
    elif node_key == "operator":
        description = f"{value} (Operator: A symbol that performs operations on one or more operands, like addition or comparison.)"

    if description:
        full_description = f"{description} Documentation URL: {doc_url}" if doc_url and node_key == "path" else description
        identified_elements[category].append(full_description)

def traverse_ast(node):
    if isinstance(node, dict):
        for key, value in node.items():
            if key == "name" and isinstance(value, str):
                category = "Identifiers"
                add_with_description(category, key, value)
            elif key == "type" and isinstance(value, str):
                add_with_description("TypeNames", key, value)
            elif key == "path":
                add_with_description("PackageAndImportPaths", key, value)
            elif key == "value" and isinstance(value, (str, int, float)):
                add_with_description("LiteralValues", key, value)
            elif key == "operator" and isinstance(value, str):
                add_with_description("Operators", key, value)
            traverse_ast(value)
    elif isinstance(node, list):
        for item in node:
            traverse_ast(item)

def process_ast_from_file(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            ast = json.load(file)
            traverse_ast(ast)
            print(json.dumps(identified_elements, indent=2))
    except FileNotFoundError:
        print(f"File not found: {file_path}")
    except json.JSONDecodeError:
        print(f"Error decoding JSON from the file: {file_path}")

# Specify the path to the "ast.json" file
file_path = "ast.json"

# Process the AST from the specified file
process_ast_from_file(file_path)